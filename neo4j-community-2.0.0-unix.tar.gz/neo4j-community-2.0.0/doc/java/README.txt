Neo4j Java Documentation
=======================================

Java language documentation for Neo4j.

* api - javadocs for all released libraries
  * [javadoc](api/index.html)


References
----------

* [Getting Started](http://docs.neo4j.org/chunked/2.0.0/introduction.html)
* [Getting Started With Java](http://docs.neo4j.org/chunked/2.0.0/server-java-rest-client-example.html)
